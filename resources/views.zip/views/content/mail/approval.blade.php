Dear {{ $id }},

Congratulations! Your approval status has been updated to 'Approved'.
Welcome to FindYourServiceProvider!.

<br><br>

Best regards,
<br>
{{ $agent }}