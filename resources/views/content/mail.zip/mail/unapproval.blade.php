Dear {{ $id }},

Your approval status has been updated to 'Pending'. Verification was unsuccessful.<br><br>
Please contact your Agent/Administrator for more information.

Best regards,<br>
{{ $agent }}
